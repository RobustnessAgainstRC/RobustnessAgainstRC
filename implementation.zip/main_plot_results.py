"""
Generates plots from raw data.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def plot_throughput_and_abort_rate(data, x_axis, x_label, size=(4, 4)):
    
    palette = sns.color_palette(("#3571aa", "#decb4a", "#d96355", "#8ec3e4"), desat=1)
    
    fig = plt.figure(constrained_layout=True, dpi=600, figsize=size)
    heights = [5, 3]
    spec = fig.add_gridspec(ncols=1, nrows=2, height_ratios=heights)
    ax1 = fig.add_subplot(spec[0, 0])
    
    sns.barplot(x=x_axis, y="throughput",
                hue="isolation_level", data=data,
                errwidth=1, capsize=.1, ax=ax1, palette=palette, saturation=1)
    plt.xlabel(None)
    plt.ylabel("Transactions / second")
    plt.legend(title=None, loc="lower center", bbox_to_anchor=(0.5, 1.05), ncol=3)
    
    ax2 = fig.add_subplot(spec[1, 0])
    
    sns.barplot(x=x_axis, y="abort_rate",
                hue="isolation_level", data=data,
                errwidth=1, capsize=.1, palette=palette, saturation=1)
    plt.xlabel(x_label)
    plt.ylabel("Aborts / second")
    plt.legend().remove()
    
    return fig


def plot_experiment_1():
    data = pd.read_csv("results/results_experiment_1.csv")
    
    fig = plot_throughput_and_abort_rate(data, "num_clients", "Number of clients", (4,4))
    fig.savefig("results/fig_experiment_1.png")


def plot_experiment_2():
    data = pd.read_csv("results/results_experiment_2.csv")
    
    data_10 = data[data["hotspot_size"] == 10]
    data_100 = data[data["hotspot_size"] == 100]
    data_1000 = data[data["hotspot_size"] == 1000]
    
    fig = plot_throughput_and_abort_rate(data_10, "hotspot_probability", "Hotspot probability")
    fig.savefig("results/fig_experiment_2_hotspot10.png")
    
    fig = plot_throughput_and_abort_rate(data_100, "hotspot_probability", "Hotspot probability")
    fig.savefig("results/fig_experiment_2_hotspot100.png")
    
    fig = plot_throughput_and_abort_rate(data_1000, "hotspot_probability", "Hotspot probability")
    fig.savefig("results/fig_experiment_2_hotspot1000.png")


def plot_experiment_3():
    data = pd.read_csv("results/results_experiment_3.csv")
    
    plt.figure(dpi=600, figsize=(6, 6))
    fig = plot_throughput_and_abort_rate(data, "hotspot_probability", "Zipfian skew")
    fig.savefig("results/fig_experiment_3.png")


def plot_experiment_4():
    data = pd.read_csv("results/results_experiment_4.csv")
    
    data_10 = data[data["hotspot_size"] == 10]
    data_100 = data[data["hotspot_size"] == 100]
    data_1000 = data[data["hotspot_size"] == 1000]
    
    fig = plot_throughput_and_abort_rate(data_10, "hotspot_probability", "Hotspot probability")
    fig.savefig("results/fig_experiment_4_hotspot10.png")
    
    fig = plot_throughput_and_abort_rate(data_100, "hotspot_probability", "Hotspot probability")
    fig.savefig("results/fig_experiment_4_hotspot100.png")
    
    fig = plot_throughput_and_abort_rate(data_1000, "hotspot_probability", "Hotspot probability")
    fig.savefig("results/fig_experiment_4_hotspot1000.png")


def plot_experiment_5():
    data = pd.read_csv("results/results_experiment_5.csv")
    
    
    plt.figure(dpi=600, figsize=(6, 6))
    fig = plot_throughput_and_abort_rate(data, "hotspot_probability", "Zipfian skew")
    fig.savefig("results/fig_experiment_5.png")


def plot_experiment_8():
    data = pd.read_csv("results/results_experiment_8.csv")
    
    fig = plot_throughput_and_abort_rate(data, "num_clients", "Number of clients", (4, 4))
    fig.savefig("results/fig_experiment_8.png")


def plot_tpcc_experiment_2():
    data = pd.read_csv("results/results_tpcc_experiment_2.csv")
    
    fig = plot_throughput_and_abort_rate(data, "num_clients", "Number of clients", (6.6,4))
    fig.savefig("results/fig_tpcc_experiment_2.png")


def plot_tpcc_experiment_6():
    data = pd.read_csv("results/results_tpcc_experiment_6.csv")
    
    plt.figure(dpi=600, figsize=(6, 6))
    fig = plot_throughput_and_abort_rate(data, "hotspot_probability", "Zipfian skew", (4.4, 4))
    fig.savefig("results/fig_tpcc_experiment_6.png")

def plot_tpcc_experiment_7():
    data = pd.read_csv("results/results_tpcc_experiment_7.csv")
    
    fig = plot_throughput_and_abort_rate(data, "hotspot_probability", "Zipfian skew")
    fig.savefig("results/fig_tpcc_experiment_7.png")

def plot_tpcc_experiment_10():
    data = pd.read_csv("results/results_tpcc_experiment_10.csv")
    
    plt.figure(dpi=600, figsize=(6, 6))
    fig = plot_throughput_and_abort_rate(data, "wh_zipf_skew", "Warehouse zipfian skew", (4.4, 4))
    fig.savefig("results/fig_tpcc_experiment_10.png")

def plot_tpcc_experiment_12():
    data_1 = pd.read_csv("results/results_tpcc_experiment_12_1.csv")
    data_5 = pd.read_csv("results/results_tpcc_experiment_12_5.csv")
    data_10 = pd.read_csv("results/results_tpcc_experiment_12_10.csv")
    data_25 = pd.read_csv("results/results_tpcc_experiment_12_25.csv")
    
    data_1["num_wh"] = 1
    data_5["num_wh"] = 5
    data_10["num_wh"] = 10
    data_25["num_wh"] = 25
    
    data = pd.concat([data_1, data_5, data_10, data_25])
    
    fig = plot_throughput_and_abort_rate(data, "num_wh", "Number of Warehouses")
    fig.savefig("results/fig_tpcc_experiment_12.png")


def main():
    plot_experiment_1()
    plot_experiment_2()
    plot_experiment_3()
    plot_experiment_4()
    plot_experiment_5()
    plot_experiment_8()
    plot_tpcc_experiment_2()
    plot_tpcc_experiment_6()
    plot_tpcc_experiment_7()
    plot_tpcc_experiment_10()
    plot_tpcc_experiment_12()

if __name__ == '__main__':
    main()