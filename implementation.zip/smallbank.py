import psycopg2

DB_SCHEMA_CREATION = """
    DROP TABLE IF EXISTS Saving;
    DROP TABLE IF EXISTS Checking;
    DROP TABLE IF EXISTS Account;

    CREATE TABLE IF NOT EXISTS Account(
        Name VARCHAR PRIMARY KEY,
        CustomerID INTEGER,
        IsPremium BOOLEAN
    );

    CREATE TABLE IF NOT EXISTS Saving(
        CustomerID INTEGER PRIMARY KEY,
        Balance INTEGER,
        InterestRate INTEGER
    );

    CREATE TABLE IF NOT EXISTS Checking(
        CustomerID INTEGER PRIMARY KEY,
        Balance INTEGER
    );
"""

INSERT_ACCOUNT = """
    INSERT INTO Account
    VALUES (%s, %s, %s);
"""

INSERT_SAVING = """
    INSERT INTO Saving
    VALUES (%s, %s, %s);
"""

INSERT_CHECKING = """
    INSERT INTO Checking
    VALUES (%s, %s);
"""

GET_CUSTOMER_ID = """
    SELECT CustomerId
    FROM Account
    WHERE Name = %s;
"""

GET_CUSTOMER_ID_PROM = """
    UPDATE Account
    SET Name = Name
    WHERE Name = %s
    RETURNING CustomerID;
"""

DEPOSIT_CHECKING_2 = """
    UPDATE Checking
    SET Balance = Balance + %s
    WHERE CustomerId = %s;
"""

TRANSACT_SAVING_2 = """
    UPDATE Saving
    SET Balance = Balance + %s
    WHERE CustomerId = %s;
"""

AMALGAMATE_3 = """
    UPDATE Saving AS new
    SET Balance = 0
    FROM Saving AS old
    WHERE new.CustomerId = %s
        AND old.CustomerId = new.CustomerId
    RETURNING old.Balance;
"""

AMALGAMATE_4 = """
    UPDATE Checking AS new
    SET Balance = 0
    FROM Checking AS old
    WHERE new.CustomerId = %s
        AND old.CustomerId = new.CustomerId
    RETURNING old.Balance;
"""

AMALGAMATE_5 = """
    UPDATE Checking
    SET Balance = Balance + %s + %s
    WHERE CustomerId = %s;
"""

GET_SAVING_BAL = """
    SELECT Balance
    FROM Saving
    WHERE CustomerId = %s;
"""

GET_CHECKING_BAL = """
    SELECT Balance
    FROM Checking
    WHERE CustomerId = %s;
"""

GET_SAVING_BAL_PROM = """
    UPDATE Saving
    Set Balance = Balance
    WHERE CustomerId = %s
    RETURNING Balance;
"""

GET_CHECKING_BAL_PROM = """
    UPDATE Checking
    SET Balance = Balance
    WHERE CustomerId = %s
    RETURNING Balance;
"""

WRITE_CHECK_4 = """
    UPDATE Checking
    SET Balance = Balance - %s
    WHERE CustomerId = %s;
"""

GO_PREMIUM_1 = """
    UPDATE Account
    SET IsPremium = True
    WHERE Name = %s
    RETURNING CustomerID;
"""

GO_PREMIUM_3 = """
    UPDATE Saving
    SET InterestRate = %s
    WHERE customerId = %s;
"""


SUM_BALANCE = """
    SELECT SUM(balance)
    FROM Checking;
"""

ACCOUNT_BALANCES = """
    SELECT S.Balance, C.Balance
    FROM Checking C, Saving S 
    WHERE C.CustomerID = %s AND S.CustomerID = C.CustomerID;
"""

ACCOUNT_INFO = """
    SELECT A.IsPremium, S.InterestRate
    FROM Account A, Saving S 
    WHERE A.CustomerID = %s AND S.CustomerID = A.CustomerID;
"""


def balance_original(db_conn, account_name):
    """R[X]R[Y]R[Z]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(GET_SAVING_BAL, (account_id,))
            bal = db_cur.fetchone()[0]
            db_cur.execute(GET_CHECKING_BAL, (account_id,))
            bal += db_cur.fetchone()[0]
            db_conn.commit()
            #print(f"Balance is {bal}")
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def balance_promoted(db_conn, account_name):
    """U[X]R[Y]R[Z]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID_PROM, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(GET_SAVING_BAL, (account_id,))
            bal = db_cur.fetchone()[0]
            db_cur.execute(GET_CHECKING_BAL, (account_id,))
            bal += db_cur.fetchone()[0]
            db_conn.commit()
            #print(f"Balance is {bal}")
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def balance_promoted_2(db_conn, account_name):
    """R[X]U[Y]U[Z]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(GET_SAVING_BAL_PROM, (account_id,))
            bal = db_cur.fetchone()[0]
            db_cur.execute(GET_CHECKING_BAL_PROM, (account_id,))
            bal += db_cur.fetchone()[0]
            db_conn.commit()
            #print(f"Balance is {bal}")
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def deposit_checking_original(db_conn, account_name, value):
    """R[X]U[Z]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(DEPOSIT_CHECKING_2, (value, account_id))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def deposit_checking_promoted(db_conn, account_name, value):
    """U[X]U[Z]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID_PROM, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(DEPOSIT_CHECKING_2, (value, account_id))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def transact_saving_original(db_conn, account_name, value):
    """R[X]U[Y]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(TRANSACT_SAVING_2, (value, account_id))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def transact_saving_promoted(db_conn, account_name, value):
    """U[X]U[Y]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID_PROM, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(TRANSACT_SAVING_2, (value, account_id))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def amalgamate_original(db_conn, account_name_from, account_name_to):
    """R[X1]R[X2]U[Y1]U[Z1]U[Z2]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID, (account_name_from,))
            account_id_from = db_cur.fetchone()[0]
            db_cur.execute(GET_CUSTOMER_ID, (account_name_to,))
            account_id_to = db_cur.fetchone()[0]
            db_cur.execute(AMALGAMATE_3, (account_id_from,))
            amount_saving = db_cur.fetchone()[0]
            db_cur.execute(AMALGAMATE_4, (account_id_from,))
            amount_checking = db_cur.fetchone()[0]
            db_cur.execute(AMALGAMATE_5, (amount_saving, amount_checking, account_id_to))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def amalgamate_promoted(db_conn, account_name_from, account_name_to):
    """U[X1]U[X2]U[Y1]U[Z1]U[Z2]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID, (account_name_from,))
            account_id_from = db_cur.fetchone()[0]
            db_cur.execute(GET_CUSTOMER_ID, (account_name_to,))
            account_id_to = db_cur.fetchone()[0]
            db_cur.execute(AMALGAMATE_3, (account_id_from,))
            amount_saving = db_cur.fetchone()[0]
            db_cur.execute(AMALGAMATE_4, (account_id_from,))
            amount_checking = db_cur.fetchone()[0]
            db_cur.execute(AMALGAMATE_5, (amount_saving, amount_checking, account_id_to))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def write_check_original(db_conn, account_name, value):
    """R[X]R[Y]R[Z]U[Z]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(GET_SAVING_BAL, (account_id,))
            bal = db_cur.fetchone()[0]
            db_cur.execute(GET_CHECKING_BAL, (account_id,))
            bal += db_cur.fetchone()[0]
            if bal < value:
                value +=1
            db_cur.execute(WRITE_CHECK_4, (value, account_id))
            db_conn.commit()
            #print(f"Balance is {bal}")
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def write_check_promoted(db_conn, account_name, value):
    """U[X]R[Y]R[Z]U[Z]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GET_CUSTOMER_ID_PROM, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(GET_SAVING_BAL, (account_id,))
            bal = db_cur.fetchone()[0]
            db_cur.execute(GET_CHECKING_BAL, (account_id,))
            bal += db_cur.fetchone()[0]
            if bal < value:
                value +=1
            db_cur.execute(WRITE_CHECK_4, (value, account_id))
            db_conn.commit()
            #print(f"Balance is {bal}")
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def go_premium_original(db_conn, account_name):
    """W[X]R[Y]W[Y]"""
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(GO_PREMIUM_1, (account_name,))
            account_id = db_cur.fetchone()[0]
            db_cur.execute(GET_SAVING_BAL, (account_id,))
            bal = db_cur.fetchone()[0]
            # interest rate is based on account info and current saving balance
            interest_rate = account_id % 2 + 1
            if bal > 1000:
                interest_rate += 2
            db_cur.execute(GO_PREMIUM_3, (interest_rate, account_id))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def create_schema(db_conn):
    db_cur = db_conn.cursor()
    db_cur.execute(DB_SCHEMA_CREATION)
    db_conn.commit()


def add_account(db_conn, account_name, account_id, account_premium,
                saving_balance, saving_interest, checking_balance, commit=True):
    db_cur = db_conn.cursor()
    db_cur.execute(INSERT_ACCOUNT, (account_name, account_id, account_premium))
    db_cur.execute(INSERT_SAVING, (account_id, saving_balance, saving_interest))
    db_cur.execute(INSERT_CHECKING, (account_id, checking_balance))
    if commit:
        db_conn.commit()


def get_account_balances(db_conn, account_id):
    db_cur = db_conn.cursor()
    db_cur.execute(ACCOUNT_BALANCES, (account_id,))
    saving, checking = db_cur.fetchone()
    db_conn.commit()
    return saving, checking


def get_account_info(db_conn, account_id):
    db_cur = db_conn.cursor()
    db_cur.execute(ACCOUNT_INFO, (account_id,))
    premium, rate = db_cur.fetchone()
    db_conn.commit()
    return premium, rate


def create_accounts(db_conn, num_accounts):
    for i in range(num_accounts):
        account_name = "A" + str(i)
        add_account(db_conn, account_name, i, False, 2*i, 0, 3*i, commit=False)
    db_conn.commit()


def sum_check(db_conn):
    db_cur = db_conn.cursor()
    db_cur.execute(SUM_BALANCE)
    db_sum = db_cur.fetchone()[0]
    db_conn.commit()
    return db_sum


def test_transactions(db_conn):
    create_schema(db_conn)
    add_account(db_conn, "A", 1, False, 10, 0, 20)
    add_account(db_conn, "B", 2, False, 100, 0, 200)
    add_account(db_conn, "C", 3, False, 10, 0, 20)
    add_account(db_conn, "D", 4, False, 100, 0, 200)
    deposit_checking_original(db_conn, "A", 50)
    deposit_checking_promoted(db_conn, "C", 50)
    s1, c1 = get_account_balances(db_conn, 1)
    s3, c3 = get_account_balances(db_conn, 3)
    if s1 != 10 or c1 != 70 or s3 != 10 or c3 != 70:
        print("ERROR: deposit_checking not behaving as expected!")
        print(s1, c1, s3, c3)
        return False
    transact_saving_original(db_conn, "A", 160)
    transact_saving_promoted(db_conn, "C", 160)
    s1, c1 = get_account_balances(db_conn, 1)
    s3, c3 = get_account_balances(db_conn, 3)
    if s1 != 170 or c1 != 70 or s3 != 170 or c3 != 70:
        print("ERROR: transact_saving not behaving as expected!")
        print(s1, c1, s3, c3)
        return False
    amalgamate_original(db_conn, "A", "B")
    amalgamate_promoted(db_conn, "C", "D")
    s1, c1 = get_account_balances(db_conn, 1)
    s2, c2 = get_account_balances(db_conn, 2)
    s3, c3 = get_account_balances(db_conn, 3)
    s4, c4 = get_account_balances(db_conn, 4)
    if s1 != 0 or c1 != 0 or s2 != 100 or c2 != 440 or\
       s3 != 0 or c3 != 0 or s4 != 100 or c4 != 440:
        print("ERROR: amalgamate not behaving as expected!")
        print(s1, c1, s2, c2, s3, c3, s4, c4)
        return False
    balance_original(db_conn, "B")
    balance_promoted(db_conn, "D")
    s2, c2 = get_account_balances(db_conn, 2)
    s4, c4 = get_account_balances(db_conn, 4)
    if s2 != 100 or c2 != 440 or s4 != 100 or c4 != 440:
        print("ERROR: balance not behaving as expected!")
        print(s2, c2)
        return False
    write_check_original(db_conn, "A", 50)
    write_check_original(db_conn, "B", 50)
    write_check_promoted(db_conn, "C", 50)
    write_check_promoted(db_conn, "D", 50)
    s1, c1 = get_account_balances(db_conn, 1)
    s2, c2 = get_account_balances(db_conn, 2)
    s3, c3 = get_account_balances(db_conn, 3)
    s4, c4 = get_account_balances(db_conn, 4)
    if s1 != 0 or c1 != -51 or s2 != 100 or c2 != 390 or\
       s3 != 0 or c3 != -51 or s4 != 100 or c4 != 390:
        print("ERROR: write_check not behaving as expected!")
        print(s1, c1, s2, c2, s3, c3, s4, c4)
        return False
    go_premium_original(db_conn, "A")
    go_premium_original(db_conn, "B")
    p1, i1 = get_account_info(db_conn, 1)
    p2, i2 = get_account_info(db_conn, 2)
    if p1 != True or i1 != 2 or p2 != True or i2 != 1:
        print("ERROR: go_premium not behaving as expected!")
        print(p1, i1, p2, i2)
        return False
    return True
