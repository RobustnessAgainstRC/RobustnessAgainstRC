import psycopg2
import time

DB_SCHEMA_CREATION = """
    DROP TABLE IF EXISTS Warehouse;
    DROP TABLE IF EXISTS District;
    DROP TABLE IF EXISTS Customer;
    DROP TABLE IF EXISTS Orders;
    DROP TABLE IF EXISTS OrderLine;
    DROP TABLE IF EXISTS Stock;

    CREATE TABLE IF NOT EXISTS Warehouse(
        WarehouseID INTEGER PRIMARY KEY,
        Info VARCHAR,
        YTD INTEGER
    );
    
    CREATE TABLE IF NOT EXISTS District(
        WarehouseID INTEGER,
        DistrictID INTEGER,
        Info VARCHAR,
        YTD INTEGER,
        NextOrderID INTEGER,
        PRIMARY KEY(WarehouseID, DistrictID)
    );
    
    CREATE TABLE IF NOT EXISTS Customer(
        WarehouseID INTEGER,
        DistrictID INTEGER,
        CustomerID INTEGER,
        Info VARCHAR,
        Balance INTEGER,
        PRIMARY KEY(WarehouseID, DistrictID, CustomerID)
    );
    
    CREATE TABLE IF NOT EXISTS Orders(
        WarehouseID INTEGER,
        DistrictID INTEGER,
        OrderID INTEGER,
        CustomerID INTEGER,
        Status VARCHAR,
        PRIMARY KEY(WarehouseID, DistrictID, OrderID)
    );
    
    CREATE TABLE IF NOT EXISTS OrderLine(
        WarehouseID INTEGER,
        DistrictID INTEGER,
        OrderID INTEGER,
        OrderLineID INTEGER,
        ItemID INTEGER,
        DeliveryInfo VARCHAR,
        Quantity INTEGER,
        PRIMARY KEY(WarehouseID, DistrictID, OrderID, OrderLineID)
    );
    
    CREATE TABLE IF NOT EXISTS Stock(
        WarehouseID INTEGER,
        ItemID INTEGER,
        Quantity INTEGER,
        PRIMARY KEY(WarehouseID, ItemID)
    );
"""

INSERT_WAREHOUSE = """
    INSERT INTO Warehouse
    VALUES (%s, %s, %s);
"""

GET_WAREHOUSE = """
    SELECT *
    FROM Warehouse
    WHERE WarehouseID = %s;
"""

INSERT_DISTRICT = """
    INSERT INTO District
    VALUES (%s, %s, %s, %s, %s);
"""

GET_DISTRICT = """
    SELECT *
    FROM District
    WHERE WarehouseID = %s and DistrictID = %s;
"""

INSERT_CUSTOMER = """
    INSERT INTO Customer
    VALUES (%s, %s, %s, %s, %s);
"""

GET_CUSTOMER = """
    SELECT *
    FROM Customer
    WHERE WarehouseID = %s and DistrictID = %s and CustomerID = %s;
"""

INSERT_ORDER = """
    INSERT INTO Orders
    VALUES (%s, %s, %s, %s, %s);
"""

GET_ORDER = """
    SELECT *
    FROM Orders
    WHERE WarehouseID = %s and DistrictID = %s and OrderID = %s;
"""

INSERT_ORDERLINE = """
    INSERT INTO OrderLine
    VALUES (%s, %s, %s, %s, %s, %s, %s);
"""

GET_ORDERLINE = """
    SELECT *
    FROM OrderLine
    WHERE WarehouseID = %s and DistrictID = %s and OrderID = %s and OrderLineID = %s;
"""

INSERT_STOCK = """
    INSERT INTO Stock
    VALUES (%s, %s, %s);
"""

GET_STOCK = """
    SELECT *
    FROM Stock
    WHERE WarehouseID = %s and ItemID = %s;
"""

READ_WAREHOUSE = """
    SELECT Info
    FROM Warehouse
    WHERE WarehouseID = %s;
"""

READ_WAREHOUSE_PROMOTED = """
    UPDATE Warehouse
    SET Info = Info
    WHERE WarehouseID = %s
    RETURNING Info;
"""

UPDATE_DISTRICT_NEXTORDERID = """
    UPDATE District
    SET NextOrderID = NextOrderID + 1
    WHERE WarehouseID = %s AND DistrictID = %s
    RETURNING NextOrderID;
"""

READ_CUSTOMER = """
    SELECT Info
    FROM Customer
    WHERE WarehouseID = %s AND DistrictID = %s AND CustomerID = %s;
"""

READ_CUSTOMER_PROMOTED = """
    UPDATE Customer
    SET Info = Info
    WHERE WarehouseID = %s AND DistrictID = %s AND CustomerID = %s
    RETURNING Info;
"""

UPDATE_STOCK_QUANTITY = """
    UPDATE Stock
    SET Quantity = Quantity - %s
    WHERE WarehouseID = %s AND ItemID = %s;
"""

UPDATE_WAREHOUSE_YTD = """
    UPDATE Warehouse
    SET YTD = YTD + %s
    WHERE WarehouseID = %s;
"""

UPDATE_DISTRICT_YTD = """
    UPDATE District
    SET YTD = YTD + %s
    WHERE WarehouseID = %s AND DistrictID = %s;
"""

UPDATE_CUSTOMER_BALANCE = """
    UPDATE Customer
    SET Balance = Balance + %s
    WHERE WarehouseID = %s AND DistrictID = %s AND CustomerID = %s;
"""

READ_ORDER = """
    SELECT Status
    FROM Orders
    WHERE WarehouseID = %s AND DistrictID = %s AND OrderID = %s;
"""

READ_ORDERLINE = """
    SELECT DeliveryInfo
    FROM OrderLine
    WHERE WarehouseID = %s AND DistrictID = %s AND OrderID = %s AND OrderLineID = %s;
"""

UPDATE_ORDER_STATUS = """
    UPDATE Orders
    SET Status = 'delivered'
    WHERE WarehouseID = %s AND DistrictID = %s AND OrderID = %s;
"""

UPDATE_ORDERLINE_DELIVERYINFO = """
    UPDATE OrderLine
    SET DeliveryInfo = 'delivered'
    WHERE WarehouseID = %s AND DistrictID = %s AND OrderID = %s AND OrderLineID = %s;
"""

UPDATE_CUSTOMER_BALANCE_DECREASE = """
    UPDATE Customer
    SET Balance = Balance - %s
    WHERE WarehouseID = %s AND DistrictID = %s AND CustomerID = %s;
"""

READ_STOCK = """
    SELECT quantity
    FROM Stock
    WHERE WarehouseID = %s and ItemID = %s;
"""


def new_order_original(db_conn, warehouse_id, district_id, customer_id, item_id1, quantity1, item_id2, quantity2, think_time=1.0):
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(READ_WAREHOUSE, (warehouse_id,))
            warehouse_info = db_cur.fetchone()
            if think_time > 0.0:
                time.sleep(think_time)
            db_cur.execute(UPDATE_DISTRICT_NEXTORDERID, (warehouse_id, district_id))
            order_id = db_cur.fetchone()[0]
            db_cur.execute(READ_CUSTOMER, (warehouse_id, district_id, customer_id))
            customer_info = db_cur.fetchone()
            db_cur.execute(INSERT_ORDER, (warehouse_id, district_id, order_id, customer_id, "created"))
            db_cur.execute(UPDATE_STOCK_QUANTITY, (quantity1, warehouse_id, item_id1))
            db_cur.execute(INSERT_ORDERLINE, (warehouse_id, district_id, order_id, 1, item_id1, "created", quantity1))
            db_cur.execute(UPDATE_STOCK_QUANTITY, (quantity2, warehouse_id, item_id2))
            db_cur.execute(INSERT_ORDERLINE, (warehouse_id, district_id, order_id, 2, item_id2, "created", quantity2))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts

def new_order_promoted(db_conn, warehouse_id, district_id, customer_id, item_id1, quantity1, item_id2, quantity2, think_time=1.0):
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(READ_WAREHOUSE_PROMOTED, (warehouse_id,))
            warehouse_info = db_cur.fetchone()
            if think_time > 0.0:
                time.sleep(think_time)
            db_cur.execute(UPDATE_DISTRICT_NEXTORDERID, (warehouse_id, district_id))
            order_id = db_cur.fetchone()[0]
            db_cur.execute(READ_CUSTOMER_PROMOTED, (warehouse_id, district_id, customer_id))
            customer_info = db_cur.fetchone()
            db_cur.execute(INSERT_ORDER, (warehouse_id, district_id, order_id, customer_id, "created"))
            db_cur.execute(UPDATE_STOCK_QUANTITY, (quantity1, warehouse_id, item_id1))
            db_cur.execute(INSERT_ORDERLINE, (warehouse_id, district_id, order_id, 1, item_id1, "created", quantity1))
            db_cur.execute(UPDATE_STOCK_QUANTITY, (quantity2, warehouse_id, item_id2))
            db_cur.execute(INSERT_ORDERLINE, (warehouse_id, district_id, order_id, 2, item_id2, "created", quantity2))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts

def payment_original(db_conn, warehouse_id, district_id, customer_id, amount, think_time=1.0):
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(UPDATE_WAREHOUSE_YTD, (amount, warehouse_id))
            if think_time > 0.0:
                time.sleep(think_time)
            db_cur.execute(UPDATE_DISTRICT_YTD, (amount, warehouse_id, district_id))
            db_cur.execute(UPDATE_CUSTOMER_BALANCE, (amount, warehouse_id, district_id, customer_id))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts

def order_status_original(db_conn, warehouse_id, district_id, customer_id, order_id, think_time=1.0):
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(READ_CUSTOMER, (warehouse_id, district_id, customer_id))
            customer_info = db_cur.fetchone()
            if think_time > 0.0:
                time.sleep(think_time)
            db_cur.execute(READ_ORDER, (warehouse_id, district_id, order_id))
            order_info = db_cur.fetchone()
            db_cur.execute(READ_ORDERLINE, (warehouse_id, district_id, order_id, 1))
            orderline1_info = db_cur.fetchone()
            db_cur.execute(READ_ORDERLINE, (warehouse_id, district_id, order_id, 2))
            orderline2_info = db_cur.fetchone()
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts

def order_status_promoted(db_conn, warehouse_id, district_id, customer_id, order_id, think_time=1.0):
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(READ_CUSTOMER_PROMOTED, (warehouse_id, district_id, customer_id))
            customer_info = db_cur.fetchone()
            if think_time > 0.0:
                time.sleep(think_time)
            db_cur.execute(READ_ORDER, (warehouse_id, district_id, order_id))
            order_info = db_cur.fetchone()
            db_cur.execute(READ_ORDERLINE, (warehouse_id, district_id, order_id, 1))
            orderline1_info = db_cur.fetchone()
            db_cur.execute(READ_ORDERLINE, (warehouse_id, district_id, order_id, 2))
            orderline2_info = db_cur.fetchone()
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def delivery_original(db_conn, warehouse_id, district_id, customer_id, order_id, price, think_time=1.0):
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(UPDATE_ORDER_STATUS, (warehouse_id, district_id, order_id))
            if think_time > 0.0:
                time.sleep(think_time)
            db_cur.execute(UPDATE_ORDERLINE_DELIVERYINFO, (warehouse_id, district_id, order_id, 1))
            db_cur.execute(UPDATE_ORDERLINE_DELIVERYINFO, (warehouse_id, district_id, order_id, 2))
            db_cur.execute(UPDATE_CUSTOMER_BALANCE_DECREASE, (price, warehouse_id, district_id, customer_id))
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts

def stock_level_original(db_conn, warehouse_id, item_id, think_time=1.0):
    num_aborts = 0
    success = False
    db_cur = db_conn.cursor()
    while not success:
        try:
            db_cur.execute(READ_STOCK, (warehouse_id, item_id))
            quantity = db_cur.fetchone()
            db_conn.commit()
            success = True
        except psycopg2.Error as e:
            #print(e)
            db_conn.rollback()
            num_aborts += 1
    return num_aborts


def create_schema(db_conn):
    db_cur = db_conn.cursor()
    db_cur.execute(DB_SCHEMA_CREATION)
    db_conn.commit()


def add_warehouse(db_conn, warehouse_id, info, ytd, commit=True):
    db_cur = db_conn.cursor()
    db_cur.execute(INSERT_WAREHOUSE, (warehouse_id, info, ytd))
    if commit:
        db_conn.commit()

def get_warehouse(db_conn, warehouse_id):
    db_cur = db_conn.cursor()
    db_cur.execute(GET_WAREHOUSE, (warehouse_id,))
    result = db_cur.fetchone()
    db_conn.commit()
    return result

def add_district(db_conn, warehouse_id, district_id, info, ytd, next_order_id, commit=True):
    db_cur = db_conn.cursor()
    db_cur.execute(INSERT_DISTRICT, (warehouse_id, district_id, info, ytd, next_order_id))
    if commit:
        db_conn.commit()

def get_district(db_conn, warehouse_id, district_id):
    db_cur = db_conn.cursor()
    db_cur.execute(GET_DISTRICT, (warehouse_id, district_id))
    result = db_cur.fetchone()
    db_conn.commit()
    return result

def add_customer(db_conn, warehouse_id, district_id, customer_id, info, balance, commit=True):
    db_cur = db_conn.cursor()
    db_cur.execute(INSERT_CUSTOMER, (warehouse_id, district_id, customer_id, info, balance))
    if commit:
        db_conn.commit()

def get_customer(db_conn, warehouse_id, district_id, customer_id):
    db_cur = db_conn.cursor()
    db_cur.execute(GET_CUSTOMER, (warehouse_id, district_id, customer_id))
    result = db_cur.fetchone()
    db_conn.commit()
    return result

def add_order(db_conn, warehouse_id, district_id, order_id, customer_id, status, commit=True):
    db_cur = db_conn.cursor()
    db_cur.execute(INSERT_ORDER, (warehouse_id, district_id, order_id, customer_id, status))
    if commit:
        db_conn.commit()

def get_order(db_conn, warehouse_id, district_id, order_id):
    db_cur = db_conn.cursor()
    db_cur.execute(GET_ORDER, (warehouse_id, district_id, order_id))
    result = db_cur.fetchone()
    db_conn.commit()
    return result

def add_orderline(db_conn, warehouse_id, district_id, order_id, orderline_id, item_id, delivery_info, quantity, commit=True):
    db_cur = db_conn.cursor()
    db_cur.execute(INSERT_ORDERLINE, (warehouse_id, district_id, order_id, orderline_id, item_id, delivery_info, quantity))
    if commit:
        db_conn.commit()

def get_orderline(db_conn, warehouse_id, district_id, order_id, orderline_id):
    db_cur = db_conn.cursor()
    db_cur.execute(GET_ORDERLINE, (warehouse_id, district_id, order_id, orderline_id))
    result = db_cur.fetchone()
    db_conn.commit()
    return result

def add_stock(db_conn, warehouse_id, item_id, quantity, commit=True):
    db_cur = db_conn.cursor()
    db_cur.execute(INSERT_STOCK, (warehouse_id, item_id, quantity))
    if commit:
        db_conn.commit()

def get_stock(db_conn, warehouse_id, item_id):
    db_cur = db_conn.cursor()
    db_cur.execute(GET_STOCK, (warehouse_id, item_id))
    result = db_cur.fetchone()
    db_conn.commit()
    return result

def create_wh_data(db_conn, init_db_config, wh_id):
    num_districts_per_warehouse = init_db_config["num_districts_per_warehouse"]
    num_customers_per_district = init_db_config["num_customers_per_district"]
    num_orders_per_customer = init_db_config["num_orders_per_customer"]
    num_items_per_warehouse = init_db_config["num_items_per_warehouse"]
    num_orders_per_district = num_customers_per_district * num_orders_per_customer
    add_warehouse(db_conn, wh_id, f"warehouse {wh_id}", 0, commit=True)
    for dist in range(num_districts_per_warehouse):
        add_district(db_conn, wh_id, dist, f"district {dist}", 0, num_orders_per_district, commit=False)
        next_order_id = 0
        for cust in range(num_customers_per_district):
            add_customer(db_conn, wh_id, dist, cust, f"customer {cust}", 100, commit=False)
            for order in range(num_orders_per_customer):
                order_id = next_order_id
                next_order_id += 1
                add_order(db_conn, wh_id, dist, order_id, cust, "created", commit=False)
                for ol in range(2):
                    item_id = order_id % num_items_per_warehouse
                    add_orderline(db_conn, wh_id, dist, order_id, ol, item_id, "created", 5, commit=False)
    for item in range(num_items_per_warehouse):
        add_stock(db_conn, wh_id, item, 1000, commit=False)
    db_conn.commit()


def create_data(db_conn, init_db_config):
    num_warehouses = init_db_config["num_warehouses"]
    for wh in range(num_warehouses):
        create_wh_data(db_conn, init_db_config, wh)
    db_conn.commit()


def test_transactions(db_conn):
    create_schema(db_conn)
    add_warehouse(db_conn, 0, "WH0", 0)
    add_stock(db_conn, 0, 0, 100)
    add_stock(db_conn, 0, 1, 100)
    add_district(db_conn, 0, 0, "DIST0", 0, 0)
    add_district(db_conn, 0, 1, "DIST1", 0, 0)
    add_customer(db_conn, 0, 0, 0, "CUST0", 100)
    new_order_original(db_conn, 0, 0, 0, 0, 10, 1, 20)
    wh = get_warehouse(db_conn, 0)
    dist = get_district(db_conn, 0, 0)
    cust = get_customer(db_conn, 0, 0, 0)
    ord = get_order(db_conn, 0, 0, 1)
    ordl1 = get_orderline(db_conn, 0, 0, 1, 1)
    ordl2 = get_orderline(db_conn, 0, 0, 1, 2)
    st1 = get_stock(db_conn, 0, 0)
    st2 = get_stock(db_conn, 0, 1)
    if wh != (0, "WH0", 0) or dist != (0, 0, "DIST0", 0, 1) or cust != (0, 0, 0, "CUST0", 100) \
        or ord != (0, 0, 1, 0, "created") or ordl1 != (0, 0, 1, 1, 0, "created", 10) \
        or ordl2 != (0, 0, 1, 2, 1, "created", 20) or st1 != (0, 0, 90) or st2 != (0, 1, 80):
        print("ERROR: new_order_original not behaving as expected!")
        print(wh, dist, cust, ord, ordl1, ordl2, st1, st2)
        return False
    
    new_order_promoted(db_conn, 0, 0, 0, 0, 30, 1, 40)
    wh = get_warehouse(db_conn, 0)
    dist = get_district(db_conn, 0, 0)
    cust = get_customer(db_conn, 0, 0, 0)
    ord = get_order(db_conn, 0, 0, 2)
    ordl1 = get_orderline(db_conn, 0, 0, 2, 1)
    ordl2 = get_orderline(db_conn, 0, 0, 2, 2)
    st1 = get_stock(db_conn, 0, 0)
    st2 = get_stock(db_conn, 0, 1)
    if wh != (0, "WH0", 0) or dist != (0, 0, "DIST0", 0, 2) or cust != (0, 0, 0, "CUST0", 100) \
        or ord != (0, 0, 2, 0, "created") or ordl1 != (0, 0, 2, 1, 0, "created", 30) \
        or ordl2 != (0, 0, 2, 2, 1, "created", 40) or st1 != (0, 0, 60) or st2 != (0, 1, 40):
        print("ERROR: new_order_original not behaving as expected!")
        print(wh, dist, cust, ord, ordl1, ordl2, st1, st2)
        return False
    
    payment_original(db_conn, 0, 0, 0, 100)
    wh = get_warehouse(db_conn, 0)
    dist = get_district(db_conn, 0, 0)
    cust = get_customer(db_conn, 0, 0, 0)
    if wh != (0, "WH0", 100) or dist != (0, 0, "DIST0", 100, 2) or cust != (0, 0, 0, "CUST0", 200):
        print("ERROR: payment_original not behaving as expected!")
        print(wh, dist, cust)
        return False
    
    order_status_original(db_conn, 0, 0, 0, 1)
    order_status_promoted(db_conn, 0, 0, 0, 1)
    wh = get_warehouse(db_conn, 0)
    dist = get_district(db_conn, 0, 0)
    cust = get_customer(db_conn, 0, 0, 0)
    ord = get_order(db_conn, 0, 0, 1)
    ordl1 = get_orderline(db_conn, 0, 0, 1, 1)
    ordl2 = get_orderline(db_conn, 0, 0, 1, 2)
    if wh != (0, "WH0", 100) or dist != (0, 0, "DIST0", 100, 2) or cust != (0, 0, 0, "CUST0", 200) \
        or ord != (0, 0, 1, 0, "created") or ordl1 != (0, 0, 1, 1, 0, "created", 10) \
        or ordl2 != (0, 0, 1, 2, 1, "created", 20):
        print("ERROR: order_status not behaving as expected!")
        print(wh, dist, cust, ord, ordl1, ordl2, st1, st2)
        return False
    
    delivery_original(db_conn, 0, 0, 0, 1, 50)
    cust = get_customer(db_conn, 0, 0, 0)
    ord = get_order(db_conn, 0, 0, 1)
    ordl1 = get_orderline(db_conn, 0, 0, 1, 1)
    ordl2 = get_orderline(db_conn, 0, 0, 1, 2)
    if cust != (0, 0, 0, "CUST0", 150) or ord != (0, 0, 1, 0, "delivered") \
        or ordl1 != (0, 0, 1, 1, 0, "delivered", 10) or ordl2 != (0, 0, 1, 2, 1, "delivered", 20):
        print("ERROR: delivery_original not behaving as expected!")
        print(cust, ord, ordl1, ordl2)
        return False
    
    stock_level_original(db_conn, 0, 1)
    wh = get_warehouse(db_conn, 0)
    st1 = get_stock(db_conn, 0, 1)
    if wh != (0, "WH0", 100) or st1 != (0, 1, 40):
        print("ERROR: stock_level_original not behaving as expected!")
        print(wh, st1)
        return False
    
    return True
