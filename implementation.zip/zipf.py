import random
#from scipy import stats

# store last params for faster zipf generation
NUM_ZIPF = 1000000
global_zipf = []
global_zipf_index = 0

def generate_zipf(n, skew):
    global global_zipf, global_zipf_index
    values = [i for i in range(n)]
    weights = [(1/(i+1))**skew for i in range(n)]
    global_zipf = random.choices(values, weights=weights, k=NUM_ZIPF)
    global_zipf_index = 0

def zipf(n, skew):
    global global_zipf, global_zipf_index
    index = global_zipf_index
    global_zipf_index = (global_zipf_index + 1) % len(global_zipf)
    if global_zipf_index == 0:
        print("warning: out of new random values!")
    return global_zipf[index]
    


# def zeta(n, theta):
#     ans = 0
#     i = 1
#     while i <= n:
#         ans += pow(1/n, theta)
#         i += 1
#     return ans
# 
# def zipf3(n, theta):
#     a = 1 / (1 - theta)
#     zetan = zeta(n, theta)
#     eta = (1 - pow(2 / n, 1 - theta)) / (1 - zeta(2,theta) / zetan)
#     u = random.random()
#     uz = u * zetan
#     if uz < 1:
#         return 1
#     if uz < 1 + pow(0.5, theta):
#         return 2
#     return int(n * pow(eta * u - eta + 1, a))
# 
# 
# def zipf2(n, theta):
#     values = [i+1 for i in range(n)]
#     weights = [(1/i) ** theta for i in values]
#     s = sum(weights)
#     weights = [i/s for i in weights]
#     distribution = stats.rv_discrete(values = (values, weights))
#     return distribution.rvs(size=1)[0]