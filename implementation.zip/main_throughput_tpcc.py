"""
Experiments on TPC-C benchmark
"""

import time
import random
import multiprocessing as mp
from timeit import default_timer as timer
import psycopg2
import tpcc
from zipf import zipf, generate_zipf
import os

# DB connection settings
# POSTGRES_DB = "test_db"
# POSTGRES_USER = "postgres"
# POSTGRES_PASSWORD = "postgres"
# POSTGRES_HOST = "localhost"
POSTGRES_DB = "postgres"
POSTGRES_USER = "postgres"
POSTGRES_PASSWORD = "postgres"
POSTGRES_HOST = os.getenv("POSTGRES_DB_HOST", default="localhost")

# Test times (in seconds)
RAMPUP_TIME = 10
TEST_TIME = 60
EXTRA_TIME = 2

# Number of tries for each test
NUM_TRIES = 5

DEFAULT_THINK_TIME=0.0

# Enumeration of available transactions
TRANSACTIONS = [
    "new_order",
    "payment",
    "order_status",
    "delivery",
    "stock_level"
]


# Implementation of the templates
TRANSACTION_FUNCTION_ORIGINAL = {
    "new_order": tpcc.new_order_original,
    "payment": tpcc.payment_original,
    "order_status": tpcc.order_status_original,
    "delivery": tpcc.delivery_original,
    "stock_level": tpcc.stock_level_original
}

TRANSACTION_FUNCTION_PROMOTED = {
    "new_order": tpcc.new_order_promoted,
    "payment": tpcc.payment_original,
    "order_status": tpcc.order_status_promoted,
    "delivery": tpcc.delivery_original,
    "stock_level": tpcc.stock_level_original
}


def connect_db():
    db_conn = None
    while db_conn is None:
        try:
            db_conn = psycopg2.connect(dbname=POSTGRES_DB, user=POSTGRES_USER,
                                       password=POSTGRES_PASSWORD,
                                       host=POSTGRES_HOST)
        except Exception as e:
            print("Could not connect to db:", e, flush=True)
            time.sleep(1)
    return db_conn


def init_db(init_db_config):
    db_conn = connect_db()
    tpcc.create_schema(db_conn)
    #tpcc.create_data(db_conn, init_db_config)
    create_data_distributed(init_db_config)
    db_conn.close()


def create_wh_data_func(init_db_config, wh_id):
    db_conn = connect_db()
    tpcc.create_wh_data(db_conn, init_db_config, wh_id)
    db_conn.close()


def create_data_distributed(init_db_config):
    num_warehouses = init_db_config["num_warehouses"]
    # Create and run client processes
    clients = []
    for client_id in range(num_warehouses):
        client = mp.Process(target=create_wh_data_func,
                            args=(init_db_config, client_id))
        client.start()
        clients.append(client)

    # Wait until all clients finished
    #print("Clients running...")
    for client in clients:
        client.join()


def set_isolation_level(db_conn, isolation_level):
    if isolation_level == "RC":
        db_conn.set_session(isolation_level=psycopg2.extensions.ISOLATION_LEVEL_READ_COMMITTED)
    elif isolation_level == "SI":
        db_conn.set_session(isolation_level=psycopg2.extensions.ISOLATION_LEVEL_REPEATABLE_READ)
    elif isolation_level == "SSI":
        db_conn.set_session(isolation_level=psycopg2.extensions.ISOLATION_LEVEL_SERIALIZABLE)
    else:
        print(f"Unknown isolation level: {isolation_level}")


def random_warehouse(init_db_config, wh_zipf_skew):
    num_warehouses = init_db_config["num_warehouses"]
    values = list(range(num_warehouses))
    weights = [(1/(i+1))**wh_zipf_skew for i in range(num_warehouses)]
    wh_id = random.choices(values, weights=weights, k=1)[0]
    return wh_id

def random_district(init_db_config, wh_zipf_skew):
    num_warehouses = init_db_config["num_warehouses"]
    num_districts_per_warehouse = init_db_config["num_districts_per_warehouse"]
    warehouse_id = random_warehouse(init_db_config, wh_zipf_skew)
    district_id = random.randrange(num_districts_per_warehouse)
    return (warehouse_id, district_id)

def random_customer(init_db_config, hotspot_customers, hotspot_probability, use_zipf, wh_zipf_skew):
    num_customers_per_district = init_db_config["num_customers_per_district"]
    # Uniform selection of warehouse + district
    warehouse_id, district_id = random_district(init_db_config, wh_zipf_skew)
    # hotspot based selection of customer within this warehouse+district
    if use_zipf:
        #print("using zipf")
        customer_id = zipf(num_customers_per_district, hotspot_probability)
    else:
        if random.random() <= hotspot_probability:
            # Choose hotspot account
            customer_id = random.randrange(hotspot_customers)
        else:
            # Choose non-hotspot account
            customer_id = random.randrange(hotspot_customers, num_customers_per_district)
    return (warehouse_id, district_id, customer_id)


def random_order(init_db_config, hotspot_customers, hotspot_probability, use_zipf, wh_zipf_skew):
    warehouse_id, district_id, customer_id = random_customer(init_db_config, hotspot_customers, hotspot_probability, use_zipf, wh_zipf_skew)
    num_orders_per_customer = init_db_config["num_orders_per_customer"]
    target_order = random.randrange(num_orders_per_customer)
    order_id = customer_id * num_orders_per_customer + target_order
    return (warehouse_id, district_id, customer_id, order_id)


def random_stock_item(init_db_config, wh_zipf_skew):
    num_warehouses = init_db_config["num_warehouses"]
    num_items_per_warehouse = init_db_config["num_items_per_warehouse"]
    warehouse_id = random_warehouse(init_db_config, wh_zipf_skew)
    item_id = random.randrange(num_items_per_warehouse)
    return (warehouse_id, item_id)

def random_new_order_item(init_db_config):
    num_items_per_warehouse = init_db_config["num_items_per_warehouse"]
    item_id = random.randrange(num_items_per_warehouse)
    quantity = random.randrange(10)
    return (item_id, quantity)


def run_transaction(db_conn, init_db_config,
                    customer_hotspot_accounts, customer_hotspot_probability,
                    transaction_function, transaction_distribution, use_zipf, wh_zipf_skew):
    # pick random transaction
    trans_weights = [transaction_distribution[t] for t in TRANSACTIONS]
    trans = random.choices(TRANSACTIONS, weights=trans_weights)[0]
    trans_func = transaction_function[trans]

    # parameters depend on chosen transaction
    if trans == "payment":
        customer = random_customer(init_db_config, customer_hotspot_accounts, customer_hotspot_probability, use_zipf, wh_zipf_skew)
        return trans_func(db_conn, customer[0], customer[1], customer[2], 100, DEFAULT_THINK_TIME)
    elif trans == "order_status":
        order = random_order(init_db_config, customer_hotspot_accounts, customer_hotspot_probability, use_zipf, wh_zipf_skew)
        return trans_func(db_conn, order[0], order[1], order[2], order[3], DEFAULT_THINK_TIME)
    elif trans == "stock_level":
        stock_item = random_stock_item(init_db_config, wh_zipf_skew)
        return trans_func(db_conn, stock_item[0], stock_item[1], DEFAULT_THINK_TIME)
    elif trans == "new_order":
        customer = random_customer(init_db_config, customer_hotspot_accounts, customer_hotspot_probability, use_zipf, wh_zipf_skew)
        it1 = random_new_order_item(init_db_config)
        it2 = random_new_order_item(init_db_config)
        return trans_func(db_conn, customer[0], customer[1], customer[2], it1[0], it1[1], it2[0], it2[1], DEFAULT_THINK_TIME)
    elif trans == "delivery":
        order = random_order(init_db_config, customer_hotspot_accounts, customer_hotspot_probability, use_zipf, wh_zipf_skew)
        price = random.randrange(1,20)
        return trans_func(db_conn, order[0], order[1], order[2], order[3], price, DEFAULT_THINK_TIME)
    else:
        print(f"ERROR: unknown template: {trans}")


def run_client(client_id, isolation_level, init_db_config,
               customer_hotspot_accounts, customer_hotspot_probability,
               transaction_function, transaction_distribution,
               warmup_time, test_time, cooldown_time,
               start_barrier, result_queue, use_zipf, wh_zipf_skew):
    if use_zipf:
        num_customers_per_district = init_db_config["num_customers_per_district"]
        generate_zipf(num_customers_per_district, customer_hotspot_probability)
    
    # Use client_id in seed to avoid different clients to use same seed
    rd = random.randrange(999999999)
    random.seed(a=rd*1000+client_id)

    total_aborts = 0
    total_transactions = 0
    # start db_connection
    db_conn = connect_db()
    set_isolation_level(db_conn, isolation_level)
    # wait until other clients are ready
    start_barrier.wait()
    # start the timer and run queries
    start_time = timer()
    start_test_time = start_time + warmup_time
    end_test_time = start_test_time + test_time
    end_time = end_test_time + cooldown_time
    while timer() < end_time:
        num_aborts = run_transaction(db_conn, init_db_config,
                                     customer_hotspot_accounts, customer_hotspot_probability,
                                     transaction_function, transaction_distribution, use_zipf, wh_zipf_skew)
        if start_test_time < timer() < end_test_time:
            total_aborts += num_aborts
            total_transactions += 1
    # collect the results in a queue
    result = (client_id, total_transactions, total_aborts)
    result_queue.put(result)


def run_testcase(isolation_level, init_db_config, num_clients,
                 customer_hotspot_accounts, customer_hotspot_probability,
                 transaction_function, transaction_distribution,
                 warmup_time, test_time, cooldown_time, use_zipf, wh_zipf_skew):
    # Initialize DB
    #print("Initializing DB...", flush=True)
    init_db(init_db_config)
    #print("Initializing DB Done!", flush=True)
    
    # Create necessary multiprocessing objects
    start_barrier = mp.Barrier(num_clients)
    result_queue = mp.Queue()

    # Create and run client processes
    clients = []
    for client_id in range(num_clients):
        client = mp.Process(target=run_client,
                            args=(client_id, isolation_level, init_db_config,
                                  customer_hotspot_accounts, customer_hotspot_probability,
                                  transaction_function, transaction_distribution,
                                  warmup_time, test_time, cooldown_time,
                                  start_barrier, result_queue, use_zipf, wh_zipf_skew))
        client.start()
        clients.append(client)

    # Wait until all clients finished
    #print("Clients running...")
    for client in clients:
        client.join()

    # Collect results from queue
    results = []
    for _ in range(num_clients):
        results.append(result_queue.get())
    #print(results)
    total_transactions = sum(r[1] for r in results)
    total_aborts = sum(r[2] for r in results)
    return total_transactions, total_aborts


def tpcc_correctness_test():
    db_conn = connect_db()
    is_correct = tpcc.test_transactions(db_conn)
    db_conn.close()
    if is_correct:
        print("info: TPC-C correctness test ok", flush=True)
    else:
        print("ERROR: TPC-C correctness test failed", flush=True)
    return is_correct


def run_experiment(experiment_id, client_sizes, init_db_config,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skews = [0.0]):
    if use_zipf:
        distr_type = "zipfian"
    else:
        distr_type = "hotspot"
    with open(f"results/results_tpcc_experiment_{experiment_id}.csv", "w") as fp:
        fp.write("test_id,isolation_level,implementation,num_clients,init_db_config,hotspot_size,hotspot_probability,distribution,transactions,aborts,throughput,abort_rate,distribution,wh_zipf_skew\n")
        for num_clients in client_sizes:
            for customer_hotspot_probability in customer_hotspot_probabilities:
                for wh_zipf_skew in wh_zipf_skews:
                    for customer_hotspot_size in customer_hotspot_sizes:
                        for il, trans_func, impl_name in il_configs:
                            print(f"\nExperiment {experiment_id}. Isolation level: {il}, customer hotspot size/probability: {customer_hotspot_size}/{customer_hotspot_probability}, num clients: {num_clients}, distribution: {distr_type}, wh_zipf_skew: {wh_zipf_skew}", flush=True)
                            for test_nr in range(NUM_TRIES):
                                trans, aborts = run_testcase(il, init_db_config, num_clients,
                                                             customer_hotspot_size, customer_hotspot_probability,
                                                             trans_func, transaction_distribution,
                                                             RAMPUP_TIME, TEST_TIME, EXTRA_TIME, use_zipf, wh_zipf_skew)
                                throughput = trans/TEST_TIME
                                abort_rate = aborts/TEST_TIME
                                fp.write(f"{test_nr},{il},{impl_name},{num_clients},\"{init_db_config}\",{customer_hotspot_size},{customer_hotspot_probability},\"{transaction_distribution}\",{trans},{aborts},{throughput:.2f},{abort_rate:.2f},{distr_type},{wh_zipf_skew}\n")
                                print(f"result {test_nr+1} of {NUM_TRIES}: {trans} transactions, {aborts} aborts. ({throughput:.2f} trans/s, {abort_rate:.2f} aborts/s)", flush=True)
                                fp.flush()


def tpcc_experiment_2():
    """
    Run the complete benchmark.
    The promoted implementation of each template is used for RC.
    The hotspot probability and size are fixed.
    Different number of clients are tested.
    """
    # Concurrency settings
    client_sizes = [1, 10, 25, 50, 100, 150, 200]
    init_db_config = {
        "num_warehouses": 25,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    customer_hotspot_sizes = [3000] # doesn't matter when using zipf
    customer_hotspot_probabilities = [0.7] # used as zipf skew parameter
    wh_zipf_skew = [0.0] # uniform distribution
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "new_order": 1,
        "payment": 1,
        "order_status": 1,
        "delivery": 1,
        "stock_level": 1
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = True
    
    run_experiment(2, client_sizes, init_db_config,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)


def tpcc_experiment_6():
    """
    Run the complete benchmark.
    The promoted implementation of each template is used for RC.
    different zipfian skews are tested.
    """
    # Concurrency settings
    client_sizes = [200]
    init_db_config = {
        "num_warehouses": 25,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    customer_hotspot_sizes = [3000] # doesn't matter when using zipf
    customer_hotspot_probabilities = [0.3, 0.5, 0.7, 0.9] # used as zipf skew parameter
    wh_zipf_skew = [0.0] # uniform distribution
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "new_order": 1,
        "payment": 1,
        "order_status": 1,
        "delivery": 1,
        "stock_level": 1
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = True
    
    run_experiment(6, client_sizes, init_db_config,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)

def tpcc_experiment_7():
    """
    Run the complete benchmark.
    The promoted implementation of each template is used for RC.
    different zipfian skews are tested.
    """
    # Concurrency settings
    client_sizes = [200]
    init_db_config = {
        "num_warehouses": 10,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    customer_hotspot_sizes = [3000] # doesn't matter when using zipf
    customer_hotspot_probabilities = [0.3, 0.5, 0.7, 0.9] # used as zipf skew parameter
    wh_zipf_skew = [0.0] # uniform distribution
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "new_order": 1,
        "payment": 1,
        "order_status": 1,
        "delivery": 1,
        "stock_level": 1
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = True
    
    run_experiment(7, client_sizes, init_db_config,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)


def tpcc_experiment_10():
    """
    Run the complete benchmark.
    The promoted implementation of each template is used for RC.
    different zipfian skews are tested.
    """
    # Concurrency settings
    client_sizes = [200]
    init_db_config = {
        "num_warehouses": 25,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    customer_hotspot_sizes = [3000] # doesn't matter when using zipf
    customer_hotspot_probabilities = [0.7] # used as zipf skew parameter
    wh_zipf_skew = [0.3, 0.5, 0.7, 0.9] # uniform distribution
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "new_order": 1,
        "payment": 1,
        "order_status": 1,
        "delivery": 1,
        "stock_level": 1
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = True
    
    run_experiment(10, client_sizes, init_db_config,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)


def tpcc_experiment_12():
    """
    Run the complete benchmark.
    The promoted implementation of each template is used for RC.
    different zipfian skews are tested.
    """
    # Concurrency settings
    client_sizes = [200]
    init_db_config_1 = {
        "num_warehouses": 1,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    init_db_config_5 = {
        "num_warehouses": 5,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    init_db_config_10 = {
        "num_warehouses": 10,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    init_db_config_25 = {
        "num_warehouses": 25,
        "num_districts_per_warehouse": 10,
        "num_customers_per_district": 3000,
        "num_orders_per_customer": 10,
        "num_items_per_warehouse": 100000
    }
    customer_hotspot_sizes = [3000] # doesn't matter when using zipf
    customer_hotspot_probabilities = [0.7] # used as zipf skew parameter
    wh_zipf_skew = [0.0] # uniform distribution
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "new_order": 1,
        "payment": 1,
        "order_status": 1,
        "delivery": 1,
        "stock_level": 1
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = True
    
    run_experiment("12_1", client_sizes, init_db_config_1,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)
    run_experiment("12_5", client_sizes, init_db_config_5,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)
    run_experiment("12_10", client_sizes, init_db_config_10,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)
    run_experiment("12_25", client_sizes, init_db_config_25,
                   customer_hotspot_sizes, customer_hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf, wh_zipf_skew)



def main():
    if not tpcc_correctness_test():
        return
    
    tpcc_experiment_2()
    tpcc_experiment_6()
    tpcc_experiment_7()
    tpcc_experiment_10()
    tpcc_experiment_12()


if __name__ == '__main__':
    mp.set_start_method('spawn')
    main()
