"""
Experiments on SmallBank benchmark
"""

import time
import random
import multiprocessing as mp
from timeit import default_timer as timer
import psycopg2
import smallbank as sb
from zipf import zipf, generate_zipf
import cProfile, io, pstats, os

# DB connection settings
# POSTGRES_DB = "test_db"
# POSTGRES_USER = "postgres"
# POSTGRES_PASSWORD = "postgres"
# POSTGRES_HOST = "localhost"
POSTGRES_DB = "postgres"
POSTGRES_USER = "postgres"
POSTGRES_PASSWORD = "postgres"
POSTGRES_HOST = os.getenv("POSTGRES_DB_HOST", default="localhost")

#print(f"postgres host is {POSTGRES_HOST}")

# Test times (in seconds)
RAMPUP_TIME = 10
TEST_TIME = 60
EXTRA_TIME = 2

# Number of tries for each test
NUM_TRIES = 5

# Enumeration of available transactions
TRANSACTIONS = [
    "balance",
    "deposit_checking",
    "transact_saving",
    "amalgamate",
    "write_check",
    "go_premium"
]


# Implementation of the templates
TRANSACTION_FUNCTION_ACCOUNT_PROMOTED = {
    "balance": sb.balance_promoted,
    "deposit_checking": sb.deposit_checking_promoted,
    "transact_saving": sb.transact_saving_promoted,
    "amalgamate": sb.amalgamate_promoted,
    "write_check": sb.write_check_promoted,
    "go_premium": sb.go_premium_original # account operation is already a write 
}

TRANSACTION_FUNCTION_ORIGINAL = {
    "balance": sb.balance_original,
    "deposit_checking": sb.deposit_checking_original,
    "transact_saving": sb.transact_saving_original,
    "amalgamate": sb.amalgamate_original,
    "write_check": sb.write_check_original,
    "go_premium": sb.go_premium_original
}


def connect_db():
    db_conn = None
    while db_conn is None:
        try:
            db_conn = psycopg2.connect(dbname=POSTGRES_DB, user=POSTGRES_USER,
                                       password=POSTGRES_PASSWORD,
                                       host=POSTGRES_HOST)
        except Exception as e:
            print("Could not connect to db:", e, flush=True)
            time.sleep(1)
    return db_conn


def init_db(num_accounts):
    db_conn = connect_db()
    sb.create_schema(db_conn)
    sb.create_accounts(db_conn, num_accounts)
    db_conn.close()


def set_isolation_level(db_conn, isolation_level):
    if isolation_level == "RC":
        db_conn.set_session(isolation_level=psycopg2.extensions.ISOLATION_LEVEL_READ_COMMITTED)
    elif isolation_level == "SI":
        db_conn.set_session(isolation_level=psycopg2.extensions.ISOLATION_LEVEL_REPEATABLE_READ)
    elif isolation_level == "SSI":
        db_conn.set_session(isolation_level=psycopg2.extensions.ISOLATION_LEVEL_SERIALIZABLE)
    else:
        print(f"Unknown isolation level: {isolation_level}")


def random_account(num_accounts, hotspot_accounts, hotspot_probability, use_zipf):
    if use_zipf:
        #print("using zipf")
        target_id = zipf(num_accounts, hotspot_probability)
    else:
        if random.random() <= hotspot_probability:
            # Choose hotspot account
            target_id = random.randrange(hotspot_accounts)
        else:
            # Choose non-hotspot account
            target_id = random.randrange(hotspot_accounts, num_accounts)
    return "A" + str(target_id)


def run_transaction(db_conn, num_accounts,
                    hotspot_accounts, hotspot_probability,
                    transaction_function, transaction_distribution, use_zipf):
    # pick random transaction
    trans_weights = [transaction_distribution[t] for t in TRANSACTIONS]
    trans = random.choices(TRANSACTIONS, weights=trans_weights)[0]
    trans_func = transaction_function[trans]

    # parameters depend on chosen transaction
    if trans == "deposit_checking" or trans == "transact_saving" or trans == "write_check":
        account = random_account(num_accounts, hotspot_accounts, hotspot_probability, use_zipf)
        return trans_func(db_conn, account, 10)
    elif trans == "amalgamate": # amalgamate
        account_from = random_account(num_accounts, hotspot_accounts, hotspot_probability, use_zipf)
        account_to = random_account(num_accounts, hotspot_accounts, hotspot_probability, use_zipf)
        return trans_func(db_conn, account_from, account_to)
    elif trans == "balance" or trans == "go_premium":
        account = random_account(num_accounts, hotspot_accounts, hotspot_probability, use_zipf)
        return trans_func(db_conn, account)
    else:
        print(f"ERROR: unknown template: {trans}")


def run_client(client_id, isolation_level, num_accounts,
               hotspot_accounts, hotspot_probability,
               transaction_function, transaction_distribution,
               warmup_time, test_time, cooldown_time,
               start_barrier, result_queue, use_zipf):
    PROFILE_ENABLED = False
    if PROFILE_ENABLED:
        pr = cProfile.Profile()
        pr.enable()
    if use_zipf:
        generate_zipf(num_accounts, hotspot_probability)
    
    # Use client_id in seed to avoid different clients to use same seed
    rd = random.randrange(999999999)
    random.seed(a=rd*1000+client_id)

    total_aborts = 0
    total_transactions = 0
    # start db_connection
    db_conn = connect_db()
    set_isolation_level(db_conn, isolation_level)
    set_deadlock_timeout(db_conn, 50)
    # wait until other clients are ready
    start_barrier.wait()
    # start the timer and run queries
    start_time = timer()
    start_test_time = start_time + warmup_time
    end_test_time = start_test_time + test_time
    end_time = end_test_time + cooldown_time
    while timer() < end_time:
        num_aborts = run_transaction(db_conn, num_accounts,
                                     hotspot_accounts, hotspot_probability,
                                     transaction_function, transaction_distribution, use_zipf)
        if start_test_time < timer() < end_test_time:
            total_aborts += num_aborts
            total_transactions += 1
    # collect the results in a queue
    result = (client_id, total_transactions, total_aborts)
    result_queue.put(result)

    if PROFILE_ENABLED:
        pr.disable()
        s = io.StringIO()
        ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
        ps.print_stats()
        with open('profile_results.txt', 'a+') as f:
            f.write(s.getvalue())


def run_testcase(isolation_level, num_accounts, num_clients,
                 hotspot_accounts, hotspot_probability,
                 transaction_function, transaction_distribution,
                 warmup_time, test_time, cooldown_time, use_zipf):
    # Initialize DB
    #print("Initializing DB...")
    init_db(num_accounts)

    # Create necessary multiprocessing objects
    start_barrier = mp.Barrier(num_clients)
    result_queue = mp.Queue()

    # Create and run client processes
    clients = []
    for client_id in range(num_clients):
        client = mp.Process(target=run_client,
                            args=(client_id, isolation_level, num_accounts,
                                  hotspot_accounts, hotspot_probability,
                                  transaction_function, transaction_distribution,
                                  warmup_time, test_time, cooldown_time,
                                  start_barrier, result_queue, use_zipf))
        client.start()
        clients.append(client)

    # Wait until all clients finished
    #print("Clients running...")
    for client in clients:
        client.join()

    # Collect results from queue
    results = []
    for _ in range(num_clients):
        results.append(result_queue.get())
    #print(results)
    total_transactions = sum(r[1] for r in results)
    total_aborts = sum(r[2] for r in results)
    return total_transactions, total_aborts


def smallbank_correctness_test():
    db_conn = connect_db()
    is_correct = sb.test_transactions(db_conn)
    db_conn.close()
    if is_correct:
        print("info: smallbank correctness test ok")
    else:
        print("ERROR: smallbank correctness test failed")
    return is_correct


def run_experiment(experiment_id, client_sizes, num_accounts,
                   hotspot_sizes, hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf):
    if use_zipf:
        distr_type = "zipfian"
    else:
        distr_type = "hotspot"
    with open(f"results/results_experiment_{experiment_id}.csv", "w") as fp:
        fp.write("test_id,isolation_level,implementation,num_clients,num_accounts,hotspot_size,hotspot_probability,distribution,transactions,aborts,throughput,abort_rate,distr_type\n")
        for num_clients in client_sizes:
            for hotspot_probability in hotspot_probabilities:
                for hotspot_size in hotspot_sizes:
                    for il, trans_func, impl_name in il_configs:
                        print(f"\nExperiment {experiment_id}. Isolation level: {il}, hotspot size/probability: {hotspot_size}/{hotspot_probability}, num clients: {num_clients}", flush=True)
                        for test_nr in range(NUM_TRIES):
                            trans, aborts = run_testcase(il, num_accounts, num_clients,
                                                         hotspot_size, hotspot_probability,
                                                         trans_func, transaction_distribution,
                                                         RAMPUP_TIME, TEST_TIME, EXTRA_TIME, use_zipf)
                            throughput = trans/TEST_TIME
                            abort_rate = aborts/TEST_TIME
                            fp.write(f"{test_nr},{il},{impl_name},{num_clients},{num_accounts},{hotspot_size},{hotspot_probability},\"{transaction_distribution}\",{trans},{aborts},{throughput:.2f},{abort_rate:.2f},{distr_type}\n")
                            print(f"result {test_nr+1} of {NUM_TRIES}: {trans} transactions, {aborts} aborts. ({throughput:.2f} trans/s, {abort_rate:.2f} aborts/s, distribution type: {distr_type})", flush=True)
                            fp.flush()


def experiment_1():
    """
    Run the biggest subset that is robust, with equal distributions.
    The original implementation of each template is used.
    The hotspot probability and size are fixed.
    Different number of clients are tested.
    """
    # Concurrency settings
    client_sizes = [1, 10, 25, 50, 100, 150, 200]
    num_accounts = 18000
    hotspot_sizes = [1000]
    hotspot_probabilities = [0.9]
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "balance": 0,
        "deposit_checking": 1,
        "transact_saving": 1,
        "amalgamate": 1,
        "write_check": 0,
        "go_premium": 0
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = False
    
    run_experiment(1, client_sizes, num_accounts,
                   hotspot_sizes, hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf)


def experiment_2():
    """
    Run the biggest subset that is robust, with equal distributions.
    The original implementation of each template is used.
    Different hotspot probability and sizes are tested.
    The number of clients is fixed.
    """
    # Concurrency settings
    client_sizes = [200]
    num_accounts = 18000
    hotspot_sizes = [10, 100, 1000]
    hotspot_probabilities = [0.1, 0.3, 0.5, 0.7, 0.9]
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "balance": 0,
        "deposit_checking": 1,
        "transact_saving": 1,
        "amalgamate": 1,
        "write_check": 0,
        "go_premium": 0
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = False
    
    run_experiment(2, client_sizes, num_accounts,
                   hotspot_sizes, hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf)

def experiment_3():
    """
    Run the biggest subset that is robust, with equal distributions.
    The original implementation of each template is used.
    Different zipfian skew parameters are tested.
    The number of clients is fixed.
    """
    #global use_zipf
    #use_zipf = True
    
    # Concurrency settings
    client_sizes = [200]
    num_accounts = 18000
    hotspot_sizes = [18000] # not used for zipfian distribution
    hotspot_probabilities = [0.5, 0.6, 0.7, 0.8, 0.9] #used as skew parameter
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "balance": 0,
        "deposit_checking": 1,
        "transact_saving": 1,
        "amalgamate": 1,
        "write_check": 0,
        "go_premium": 0
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = True
    
    run_experiment(3, client_sizes, num_accounts,
                   hotspot_sizes, hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf)


def experiment_4():
    """
    Run the complete workload with promoted account-operations, with equal distributions.
    The promoted implementation of each template is used for RC.
    The original implementation of each template is used for SI and SSI.
    Different hotspot probability and sizes are tested.
    The number of clients is fixed.
    """
    # Concurrency settings
    client_sizes = [200]
    num_accounts = 18000
    hotspot_sizes = [10, 100, 1000]
    hotspot_probabilities = [0.1, 0.3, 0.5, 0.7, 0.9]
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "balance": 1,
        "deposit_checking": 1,
        "transact_saving": 1,
        "amalgamate": 1,
        "write_check": 1,
        "go_premium": 1
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_ACCOUNT_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = False
    
    run_experiment(4, client_sizes, num_accounts,
                   hotspot_sizes, hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf)


def experiment_5():
    """
    Run the biggest subset that is robust, with equal distributions.
    The original implementation of each template is used.
    Different zipfian skew parameters are tested.
    The number of clients is fixed.
    """
    #global use_zipf
    #use_zipf = True

    # Concurrency settings
    client_sizes = [200]
    num_accounts = 18000
    hotspot_sizes = [18000] # not used for zipfian distribution
    hotspot_probabilities = [0.5, 0.6, 0.7, 0.8, 0.9] #used as skew parameter

    # Integer weight distribution of transactions
    transaction_distribution = {
        "balance": 1,
        "deposit_checking": 1,
        "transact_saving": 1,
        "amalgamate": 1,
        "write_check": 1,
        "go_premium": 1
    }

    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_ACCOUNT_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]

    use_zipf = True

    run_experiment(5, client_sizes, num_accounts,
                   hotspot_sizes, hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf)


def experiment_8():
    """
    Based on experimental setup by Fekete
    The hotspot probability and size are fixed.
    Different number of clients are tested.
    """
    # Concurrency settings
    client_sizes = [1, 10, 25, 50, 100, 150, 200]
    num_accounts = 18000
    hotspot_sizes = [1000]
    hotspot_probabilities = [0.9]
    
    # Integer weight distribution of transactions
    transaction_distribution = {
        "balance": 1,
        "deposit_checking": 1,
        "transact_saving": 1,
        "amalgamate": 1,
        "write_check": 1,
        "go_premium": 1
    }
    
    # Link isolation levels with corresponding implementation of templates
    il_configs = [
        ("RC", TRANSACTION_FUNCTION_ACCOUNT_PROMOTED, "promoted"),
        ("SI", TRANSACTION_FUNCTION_ORIGINAL, "original"),
        ("SSI", TRANSACTION_FUNCTION_ORIGINAL, "original")
    ]
    
    use_zipf = False
    
    run_experiment(8, client_sizes, num_accounts,
                   hotspot_sizes, hotspot_probabilities,
                   transaction_distribution, il_configs, use_zipf)


def set_deadlock_timeout(db_conn, ms):
    db_cur = db_conn.cursor()
    db_cur.execute("SET deadlock_timeout TO %s;", (ms,))
    db_conn.commit()

def main():
    if not smallbank_correctness_test():
        return
    
    experiment_1()
    experiment_2()
    experiment_3()
    experiment_4()
    experiment_5()
    experiment_8()


if __name__ == '__main__':
    mp.set_start_method('spawn')
    main()
